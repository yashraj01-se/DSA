import { Loader } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect } from "react";
import { Experience } from "./components/Experience";
import { UI } from "./components/UI";

function App() {
  useEffect(() => {
    const resumeAudioContext = () => {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;

      if (!window.myAudioContext) {
        window.myAudioContext = new AudioContext();
      }

      const context = window.myAudioContext;
      if (context.state === "suspended") {
        context.resume().then(() => {
          console.log("Audio context resumed.");
        }).catch((err) => {
          console.warn("Audio resume blocked:", err);
        });
      }
    };

    // Try resume on load
    resumeAudioContext();

    // Ensure resume on user interaction (browser safe)
    const handleClick = () => {
      resumeAudioContext();
      window.removeEventListener("click", handleClick);
    };

    window.addEventListener("click", handleClick);

    return () => window.removeEventListener("click", handleClick);
  }, []);

  return (
    <>
      <UI />
      <Loader />
      <Canvas shadows camera={{ position: [-0.5, 1, 4], fov: 45 }}>
        <group position-y={0}>
          <Suspense fallback={null}>
            <Experience />
          </Suspense>
        </group>
      </Canvas>
    </>
  );
}

export default App;
