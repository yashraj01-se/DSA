import { PositionalAudio } from "@react-three/drei";
import { useRef, useEffect } from "react";

const Backgroundmusic = () => {
  const soundRef = useRef();

  useEffect(() => {
    const sound = soundRef.current;

    const playSound = () => {
      if (!sound) return;

      const interval = setInterval(() => {
        if (sound.buffer) {
          clearInterval(interval);

          if (!sound.isPlaying) {
            sound.setVolume(0);
            sound.play(); // No `.then()` here
            console.log("🔊 Music started playing");

            // Fade in
            let volume = 0;
            const fadeIn = setInterval(() => {
              volume += 0.01;
              if (volume >= 0.5) {
                volume = 0.5;
                clearInterval(fadeIn);
              }
              sound.setVolume(volume);
            }, 100);
          }
        }
      }, 100);
    };

    const handleUserGesture = () => {
      if (sound?.context?.state === "suspended") {
        sound.context.resume().then(() => {
          console.log("🟢 AudioContext resumed");
          playSound();
        });
      } else {
        playSound();
      }

      window.removeEventListener("click", handleUserGesture);
    };

    window.addEventListener("click", handleUserGesture);

    return () => {
      window.removeEventListener("click", handleUserGesture);
    };
  }, []);

  return (
    <PositionalAudio
      ref={soundRef}
      url="/audios/memories_piano_m5.mp3"
      distance={10}
      loop
    />
  );
};

export default Backgroundmusic;
