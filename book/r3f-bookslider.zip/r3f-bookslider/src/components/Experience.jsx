import { Environment, OrbitControls } from "@react-three/drei";
import { Book } from "./Book";
import Backgroundmusic from "./Backgroundmusic"; // ✅ Import music component

export const Experience = () => {
  return (
    <>
      {/* Book Component Group */}
      <group position={[0.1, 0.23, 0]} scale={[1.4, 1.4, 1.4]} rotation={[-0.3, 0.0, 0]}>
        <Book />
      </group>

      {/* 🎵 Music attached to an invisible dummy mesh */}
      <mesh position={[0, 1, 0]} visible={false}>
        <Backgroundmusic />
      </mesh>

      {/* Controls and Environment */}
      <OrbitControls />
      <Environment preset="studio" />

      {/* Lighting */}
      <directionalLight
        position={[2, 5, 2]}
        intensity={2.5}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-bias={-0.0001}
      />

      {/* Ground Shadow Plane */}
      <mesh position-y={-1.5} rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[100, 100]} />
        <shadowMaterial transparent opacity={0.2} />
      </mesh>
    </>
  );
};
